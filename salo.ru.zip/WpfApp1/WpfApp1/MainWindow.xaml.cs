﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {



        private Game game;
        private Player PL;
        public MainWindow()
        {
            InitializeComponent();
            game = new Game();
            PL = new Player(game.Cells);
            renderCells();
            
            mCanvas.Children.Add(PL);
        }          

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {

            switch (e.Key)
            {
                case Key.Left:
                    PL.MoveLeft();
                    break;
                case Key.Right:
                    PL.MoveRight();
                    break;
                case Key.Up:
                    PL.MoveUp();
                    break;
                case Key.Down:
                    PL.MoveDown();
                    break;
            }
            renderCells();
            if (PL.PosX == game._Width-1  && PL.PosY == game._Height -1)
            {
                MessageBox.Show("Вы выиграли игра закончина","Конец");
            }
        }

        private void renderCells()
            {
            //for (int y = 0; y < game._Height; y++)
            //    for (int x = 0; x < game._Width; x++)
            //    {
            int x = PL.PosX;
            int y = PL.PosY;
                        if (game.Cells[x, y].Top == CellState.Close)
                            mCanvas.Children.Add(new Line()
                            {
                                Stroke = Brushes.Black,
                                StrokeThickness = 1,
                                X1 = 20 * x,
                                Y1 = 20 * y,
                                X2 = 20 * x + 20,
                                Y2 = 20 * y
                            });

                        if (game.Cells[x, y].Left == CellState.Close)
                            mCanvas.Children.Add(new Line()
                            {
                                Stroke = Brushes.Black,
                                StrokeThickness = 1,
                                X1 = 20 * x,
                                Y1 = 20 * y,
                                X2 = 20 * x,
                                Y2 = 20 * y + 20
                            });

                        if (game.Cells[x, y].Right == CellState.Close)
                            mCanvas.Children.Add(new Line()
                            {
                                Stroke = Brushes.Black,
                                StrokeThickness = 1,
                                X1 = 20 * x + 20,
                                Y1 = 20 * y,
                                X2 = 20 * x + 20,
                                Y2 = 20 * y + 20
                            });

                        if (game.Cells[x, y].Bottom == CellState.Close)
                            mCanvas.Children.Add(new Line()
                            {
                                Stroke = Brushes.Black,
                                StrokeThickness = 1,
                                X1 = 20 * x,
                                Y1 = 20 * y + 20,
                                X2 = 20 * x + 20,
                                Y2 = 20 * y + 20
                            });
                    //}
            }
        }
    }
