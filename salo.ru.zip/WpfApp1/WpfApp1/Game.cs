﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public class Game
    {
        public int _Width { get; private set; }
            public int _Height { get; private set; }
        public Cell[,] Cells { get; protected set; }
        public Game()
        {
          Initialized();
        }
        protected void Initialized()
        {
            
            _Width = 30;
            _Height = 20;
            Cells = new Cell[_Width, _Height];

            for (int y = 0; y < _Height; y++)
                for (int x = 0; x < _Width; x++)
                    Cells[x, y] = new Cell(new Point(x, y));

            Random rand = new Random();
            Int32 startX = rand.Next(_Width);
            Int32 startY = rand.Next(_Height);

            Stack<Cell> path = new Stack<Cell>();

            Cells[startX, startY].Visited = true;
            path.Push(Cells[startX, startY]);

            while (path.Count > 0)
            {
                Cell _cell = path.Peek();

                List<Cell> nextStep = new List<Cell>();
                if (_cell.Position.X > 0 && !Cells[Convert.ToInt32(_cell.Position.X - 1), Convert.ToInt32(_cell.Position.Y)].Visited)
                    nextStep.Add(Cells[Convert.ToInt32(_cell.Position.X) - 1, Convert.ToInt32(_cell.Position.Y)]);
                if (_cell.Position.X < _Width - 1 && !Cells[Convert.ToInt32(_cell.Position.X) + 1, Convert.ToInt32(_cell.Position.Y)].Visited)
                    nextStep.Add(Cells[Convert.ToInt32(_cell.Position.X) + 1, Convert.ToInt32(_cell.Position.Y)]);
                if (_cell.Position.Y > 0 && !Cells[Convert.ToInt32(_cell.Position.X), Convert.ToInt32(_cell.Position.Y) - 1].Visited)
                    nextStep.Add(Cells[Convert.ToInt32(_cell.Position.X), Convert.ToInt32(_cell.Position.Y) - 1]);
                if (_cell.Position.Y < _Height - 1 && !Cells[Convert.ToInt32(_cell.Position.X), Convert.ToInt32(_cell.Position.Y) + 1].Visited)
                    nextStep.Add(Cells[Convert.ToInt32(_cell.Position.X), Convert.ToInt32(_cell.Position.Y) + 1]);

                if (nextStep.Count() > 0)
                {
                    Cell next = nextStep[rand.Next(nextStep.Count())];

                    if (next.Position.X != _cell.Position.X)
                    {
                        if (_cell.Position.X - next.Position.X > 0)
                        {
                            _cell.Left = CellState.Open;
                            next.Right = CellState.Open;
                        }
                        else
                        {
                            _cell.Right = CellState.Open;
                            next.Left = CellState.Open;
                        }
                    }
                    if (next.Position.Y != _cell.Position.Y)
                    {
                        if (_cell.Position.Y - next.Position.Y > 0)
                        {
                            _cell.Top = CellState.Open;
                            next.Bottom = CellState.Open;
                        }
                        else
                        {
                            _cell.Bottom = CellState.Open;
                            next.Top = CellState.Open;
                        }
                    }

                    next.Visited = true;
                    path.Push(next);
                }
                else
                {
                    path.Pop();
                }
            }            

        }
    }
   public enum CellState { Close, Open };
   public class Cell
    {
        public Cell(Point currentPosition)
        {
            Visited = false;
            Position = currentPosition;
        }

        public CellState Left { get; set; }
        public CellState Right { get; set; }
        public CellState Bottom { get; set; }
        public CellState Top { get; set; }
        public Boolean Visited { get; set; }
        public Point Position { get; set; }
    }    
    public class Player : Grid
    {

        public int PosX { get; private set; }
        public int PosY { get; private set; }
        private Cell[,] Cells;
        public Player(Cell[,] Cells)
        {
            this.Cells = Cells;
            PosX = 0;
            PosY = 0;
            Width = 16;
            Height = 16;
            Background = Brushes.Red;
            Margin = new Thickness(2, 2, 0, 0);

        }
        public void MoveLeft()
        {
            if (Cells[PosX, PosY].Left == CellState.Open)
            {
                PosX--;
                Margin = new Thickness(Margin.Left - 20, Margin.Top, 0, 0);
            }
        }
        public void MoveRight()
        {
            if (Cells[PosX, PosY].Right == CellState.Open)
            {
                PosX++;
                Margin = new Thickness(Margin.Left + 20, Margin.Top, 0, 0);
            }
        }
        public void MoveUp()
        {
            if (Cells[PosX, PosY].Top == CellState.Open)
            {
                PosY--;
                Margin = new Thickness(Margin.Left, Margin.Top - 20, 0, 0);
            }
        }
        public void MoveDown()
        {

            if (Cells[PosX, PosY].Bottom == CellState.Open)
            {
                PosY++;
                Margin = new Thickness(Margin.Left, Margin.Top + 20, 0, 0);
            }

        }
    }
}
